<?php

$_['entry_instore']   = 'In store';
$_['entry_instock']   = 'Waiting 2-3 days';
$_['entry_intrade']   = 'Under the order';
$_['entry_null']      = 'Not available';
$_['text_multistore'] = 'In Store';