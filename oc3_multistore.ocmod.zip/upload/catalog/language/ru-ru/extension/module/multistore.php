<?php

$_['entry_instore']   = 'В наличии';
$_['entry_instock']   = 'Ожидание 2-3 дня';
$_['entry_intrade']   = 'Под заказ';
$_['entry_null']      = 'Отсутсвует';
$_['text_multistore'] = 'Самовывоз';