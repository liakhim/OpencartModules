<?php

class ControllerExtensionModuleMultistore extends Controller {

	private $error = array();
	private $version = '1.1.3';

	public function index() {
		
		$this->load->language('extension/module/multistore');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('extension/module/multistore');

		$data['user_token'] = $this->session->data['user_token'];

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$post = $this->request->post;

			// Если не выбран магазиин по-умолчанию, то выберем первый из списка
			if (!isset($post['module_multistore_default']) && isset($post['multistores'])) {
				$current = current($post['multistores']);
			}
			
			// Сохраняем настройки модуля
			$this->model_setting_setting->editSetting('module_multistore', $post);

			// Сохраняем сами магазины в отдельную таблицу
			if (isset($post['multistores'])) {
				$this->model_extension_module_multistore->setMultistores($post['multistores']);
			} else {
				// Удаляем
				$this->model_extension_module_multistore->setMultistores();
			}

			$data['success'] = $this->language->get('text_success');
			
		}

		$data['error'] = array();

		if (isset($this->error['permission'])) {
			$data['error'][] = $this->error['permission'];
		}

		if (!file_exists(DIR_SYSTEM.'library/PHPExcel.php')) {
			$data['error'][] = $this->language->get('error_phpexcel');
		}

		$data['multistores'] = $this->model_extension_module_multistore->getMultistores();
		
		if (isset($this->request->post['module_multistore_status'])) {
			$data['module_multistore_status'] = $this->request->post['module_multistore_status'];
		} else {
			$data['module_multistore_status'] = $this->config->get('module_multistore_status');
		}

		if (isset($this->request->post['module_multistore_default'])) {
			$data['module_multistore_default'] = $this->request->post['module_multistore_default'];
		} elseif ($this->config->get('module_multistore_default')) {
			$data['module_multistore_default'] = $this->config->get('module_multistore_default');
		} elseif (!empty($data['multistores'])) {
			$data['module_multistore_default'] = $data['multistores'][0]['multistore_id'];
		} else {
			$data['module_multistore_default'] = '';
		}

		if (isset($this->request->post['module_multistore_template'])) {
			$data['module_multistore_template'] = $this->request->post['module_multistore_template'];
		} else {
			$data['module_multistore_template'] = $this->config->get('module_multistore_template');
		}

		if (isset($this->request->post['module_multistore_modificator'])) {
			$data['module_multistore_modificator'] = $this->request->post['module_multistore_modificator'];
		} else {
			$data['module_multistore_modificator'] = $this->config->get('module_multistore_modificator');
		}

		if (isset($this->request->post['module_multistore_empty'])) {
			$data['module_multistore_empty'] = $this->request->post['module_multistore_empty'];
		} else {
			$data['module_multistore_empty'] = $this->config->get('module_multistore_empty');
		}

		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$data['breadcrumbs'] = array();
 
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/multistore', 'user_token=' . $this->session->data['user_token'], true)
		);

		
		$data['version'] = sprintf($this->language->get('version'), $this->version);

		$data['action'] = $this->url->link('extension/module/multistore', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/multistore', $data));
	}

	protected function validate() {
		
		// Доступ
		if (!$this->user->hasPermission('modify', 'extension/module/multistore')) {
			$this->error['permission'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function import(){

		$this->load->model('extension/module/multistore');
		$this->load->language('extension/module/multistore');

		$json = array();

		// Check method
		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_method');
		}

		// Get file code
		if (!$json) {

			if (isset($this->request->post['code'])) {

				$this->load->model('tool/upload');
				$result = $this->model_tool_upload->getUploadByCode($this->request->post['code']);
				if (empty($result['filename'])) {
					$json['error'] = $this->language->get('error_file_code');
				}
				
			} else {
				$json['error'] = $this->language->get('error_file_upload');
			}

		}

		// Получаем адрес файла
		if (!$json) {
				
			$products = $this->model_extension_module_multistore->readFile($result['filename']);

			var_dump($products);

			if (empty($products)) {
				$json['error'] = $this->language->get('error_file_empty');
			}
		}

		if (!$json) {

			$success 	= 0;
			$failed 	= 0;

			$this->load->model('catalog/product');
			foreach($products as $key => $product){

				$data_search = array();

				if (isset($product['name'])) {
					$data_search['filter_name'] = $product['name'];
				}

				if (isset($product['model'])) {
					$data_search['filter_model'] = $product['model'];
				}

				$search = $this->model_catalog_product->getProducts($data_search);

				if (!empty($search)){
					$products[$key]['product_id'] = $search[0]['product_id'];
					$success++;
				} else {
					unset($products[$key]);
					$failed++;
				}

			}

			if (empty($products)) {
				$json['error'] = $this->language->get('error_search_products');
			}

		}

		if (!$json) {

			$product_updated = array();
			foreach($products as $product){
				$product_id = $product['product_id'];
				$this->model_extension_module_multistore->setProductMultistores($product_id, $product);
			}

			// Обновляем общее количество
			foreach($product_updated as $quantity){
				
			}

			$json['products'] = $products;
			$json['success'] = $success;
			$json['failed'] = $failed;

		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

	}

	public function getTemplate(){

		$this->load->language('extension/module/multistore');
		$this->load->model('extension/module/multistore');

		$json = array();

		// Check method
		if ($this->request->server['REQUEST_METHOD'] != 'GET') {
			$json['error'] = $this->language->get('error_method');
		}

		// Get multistores
		if (!$json) {

			$multistores = $this->model_extension_module_multistore->getMultistores();
			if (empty($multistores)) {
				$json['error'] = $this->language->get('error_multistore_empty');
			}

		}

		// Получаем сам файл
		if (!$json) {
			$this->load->model('extension/module/multistore');
			$json['route'] = $this->model_extension_module_multistore->createTemplate($multistores);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

	}

	public function install() {
      $this->load->model('extension/module/multistore');
      $this->model_extension_module_multistore->install();
  }

  public function uninstall() {
		$this->load->model('extension/module/multistore');
		$this->model_extension_module_multistore->uninstall();
	}

}